﻿#!/usr/bin/env python
#-*- coding: utf-8 -*-
import socket
import time
import random
import json
import gevent
from gevent.pool import Pool
from gevent.queue import Queue ,Empty 

def ip_change(startip='',count=None):
    ip=[startip]
    ip_old=startip.split('.')
    for i in range(count-1):
        ip_old[3]=int(ip_old[3])+1
        if int(ip_old[3]) == 255 :
            ip_old[3]=1
            ip_old[2]=int(ip_old[2])+1
            if int(ip_old[2]) == 255 :
                ip_old[2] = 1
                ip_old[1] = int(ip_old[1])+1
                if int(ip_old[1])==255:
                    ip_old[1] = 1
                    ip_old[0] = int(ip_old[0])+1
        for a in range(len(ip_old)):
            ip_old[a]=str(ip_old[a])
        ip.append('.'.join(ip_old))
    return ip

ips_sn=['564D9A04-D5D7-7105-84F1-3A382A5E645A',]
ips_srcport=range(2048,6000)
ips_dstport=range(100,2000)
ips_srcip_list=ip_change(startip='220.245.178.131',count=20)
ips_dstip_list=ip_change(startip='66.66.0.41',count=20)
ips_userid=['1']
ips_protocol=['TCP','UDP']
ips_protocoltype=['TSL','HTTP','UDP','FTP','SSL','TCP','IMAP','oracle','mysql','elastcsearch']
ips_srcmac=['01:01:01:01:01:01']
ips_dstmac=['02:02:02:02:02:02']
ips_appname=['http','ssl','http-picture','others','people.com','xinhuanet','chinanet','financal','sina-book','tacas','microsoft-resource']
ips_ruleid=['1']
ips_eventid=['0x125322']
ips_eventset=['All']
ips_eventname=['Web Microsoft VBScript ASLR Security Bypass Vulnerability(CVE-2015-1684)','FINGER Cfingerd Wildcard Argument Information Disclosure b(CVE-1999-0259)','TCP Cybercop Operating System PA12 Exploration [Scanning]','Web Interactive Story story.pl next Parameter Traversal Arbitrary File Access(CVE-2001-0804)','Web Cognos Powerplay Web Edition Dynamic Directory Vulnerability(BID-491)','Web jigsaw DoS [CGIAttack]','ICMP NetComm NB1300 Malformed Ping Saturation DoS(CVE-2005-0895)','TCP IIS SSL Remote DoS Vulnerability Exploitation [Vulnerabilities]','Web DOMINO BaseTarget Cross-Site Scripting(BID-6904)','Web SquirrelMail Read Body.php XSS(CVE-2002-1341)']
ips_eventtype=['InformationDisclosure','BufferOverflow','DirectoryTraversal','Backdoor','DoS','CommandExecution','WormVirus','XSS','VulnerabilityScanning','SQLInjection','RequestVulnerability']
ips_category=['entertainment','game','shopping','financial-planning','life-inquiry','interests','education','sociality','news','email','industry-portal','internet-portal','online-video','computer','ip-address','uncategory']
ips_action=['pass','reset','drop','drop_session','block_source']

def get_ips_send_data():
    data=[]
    data.append('SerialNum=%s'%random.choice(ips_sn))
    data.append('GenTime=\"%s\"'%time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()))
    data.append('UserID=%s'%random.choice(ips_userid))
    data.append('UserName=%s'%random.choice(ips_srcip_list))
    data.append('SrcIP=%s'%random.choice(ips_srcip_list))
    data.append('DstIP=%s'%random.choice(ips_dstip_list))
    data.append('Protocol=%s'%random.choice(ips_protocol))
    data.append('SrcPort=%s'%random.choice(ips_srcport))
    data.append('DstPort=%s'%random.choice(ips_dstport))
    data.append('SrcMac=%s'%random.choice(ips_srcmac))
    data.append('DstMac=%s'%random.choice(ips_dstmac))
    data.append('AppName=%s'%random.choice(ips_appname))
    data.append('RuleID=%s'%random.choice(ips_ruleid))
    data.append('EventID=%s'%random.choice(ips_eventid))
    data.append('EventSet=%s'%random.choice(ips_eventset))
    data.append('EventName=\"%s\"'%random.choice(ips_eventname))
    data.append('EventType=%s'%random.choice(ips_eventtype))
    data.append('ProtocolType=%s'%random.choice(ips_protocoltype))
    data.append('Action=%s'%random.choice(ips_action))
    return ' '.join(data)
    
def send_log_bps(sock,bps=1000):
    loop_send = bps/10
    last_send = bps % 10
    s_time=time.time()
    for a in range(10):
        if a == 9 :
            loop_send+=last_send
        for num in range(loop_send):
            ips_time='{} {:>2} {}'.format(time.strftime("%b",time.localtime()),time.localtime()[2],time.strftime("%H:%M:%S",time.localtime()))
            data=get_ips_send_data()
            sock.send("<213>%s info IPS: %s\n"%(ips_time,data))
        end_time=time.time()-s_time
        if 0< end_time <= 0.1 :
            sleeptime=0.1-end_time
            gevent.sleep(sleeptime)
            #print("sleep time %s"%sleeptime)
            s_time=time.time() 

def send_log_total_time(cloud_ip,que,total_time=10,bps=1000):
    '''单进程发送日志，total_time 运行时间， bps 发送速率，日志条目数/s
    '''
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock.connect((cloud_ip,514))
    start_time=ss_time=time.time()
    for t in range(total_time) :
        send_log_bps(sock,bps)
        #print("")
        que.put(bps)
        es_time=time.time()
        #print("send packet %s, used time %s"%(bps,es_time-ss_time))
        sleeptime=1-(es_time - ss_time)
        if 0< sleeptime :
            gevent.sleep(sleeptime)
        ss_time=time.time()
    sock.close()
    end_time=time.time()

def get_bps(que,total_time):
    for x in range(total_time):
        start_time=time.time()
        gevent.sleep(1)
        bps=0
        while not que.empty():
            bps+=int(que.get())
        end_time=time.time()
        print("total send packets %s\n total used time %.1s."%(bps,(end_time-start_time)))

def send_log_gevent(cloud_ip,total_time=10,bps=1000,concurrent=12):
    '''多进程并发发送log日志
    total_time 并发发送时间
    bps 每个进程的日志发送速率
    concurrent 并发数
    '''
    que=Queue()
    pool=Pool(concurrent+1)
    for x in range(concurrent):
        pool.spawn(send_log_total_time,cloud_ip,que,total_time,bps)
    pool.spawn(get_bps,que,total_time)
    pool.join()
    #gevent.joinall([ pool.spawn(send_log_total_time,total_time,bps) for x in range(concurrent) ])

#send_log_total_time(total_time=10,bps=5000)
cloud_ip='192.168.181.20'
send_log_gevent(cloud_ip,total_time=360,bps=20,concurrent=1)
