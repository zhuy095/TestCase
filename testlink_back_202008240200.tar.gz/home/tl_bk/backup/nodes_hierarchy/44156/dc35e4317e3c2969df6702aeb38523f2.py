#!/usr/bin/python
import socket,time,multiprocessing

host='172.11.0.10'
port=80
num=100
def get_socket(host,port):
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect((host,port))
    time.sleep(10)
    s.close()

pool=multiprocessing.Pool(processes=num)
for i in range(num):
    print("start %d"%i)
    pool.apply_async(get_socket,(host,port,))
pool.close()
pool.join()

