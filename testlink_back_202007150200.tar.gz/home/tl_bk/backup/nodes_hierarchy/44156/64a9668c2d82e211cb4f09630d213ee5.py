#!/usr/bin/python
import socket
host='172.20.0.220'
port=200

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind((host,port))
s.listen(1)
while 1:
	conn,addr=s.accept()
	print('Connected by %s'%str(addr))
s.close()
